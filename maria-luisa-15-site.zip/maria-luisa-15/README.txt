CONVITE DIGITAL — MARIA LUISA XV

Como usar:
1. Abra index.html em um navegador ou publique a pasta em qualquer hospedagem estática (Netlify, Vercel, GitHub Pages etc.).
2. Para adicionar a trilha sonora, coloque um arquivo chamado trilha.mp3 na mesma pasta do index.html.
3. Substitua os blocos “Sua foto” pelos arquivos de fotos da debutante. O layout já está preparado para fotos verticais e horizontais.
4. A seção de presentes está marcada como “em breve” e pode receber depois o link da lista/Pix/loja.
5. O formulário de RSVP atualmente mostra uma confirmação e salva a resposta no navegador (localStorage). Para receber respostas de convidados de verdade, conecte o formulário a um serviço de formulário ou backend.

MAPA:
O botão “Ver localização” abre uma busca no Google Maps para The Palace Eventos, São Carlos/SP.

REFERÊNCIA:
A organização da informação foi inspirada na lógica de experiência de convite digital indicada pelo site de referência fornecido pela cliente, sem copiar design, textos, imagens ou identidade visual.
